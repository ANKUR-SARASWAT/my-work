export const products = [
  {
    flight_no: 'AI-777',
    price: 3799,
    source: 'Pune',
    destination:'New Delhi',
    depart:'14:00',
    arrive:'17:00'
  },
  {
    flight_no: 'AI-776',
    price: 2799,
    source: 'Pune',
    destination:'New Delhi',
    depart:'12:00',
    arrive:'13:00'
  },
  {
    flight_no: 'AI-707',
    price: 3799,
    source: 'New Delhi',
    destination:'Pune',
    depart:'11:00',
    arrive:'13:00'
  },
  {
    flight_no: 'AI-707',
    price: 1799,
    source: 'New Delhi',
    destination:'Pune',
    depart:'10:00',
    arrive:'12:00'
  },
  {
    flight_no: 'AI-999',
    price: 4799,
    source: 'New Delhi',
    destination:'Mumbai',
    depart:'10:00',
    arrive:'12:00'
  },
  {
    flight_no: 'AI-909',
    price: 3499,
    source: 'Mumbai',
    destination:'New Delhi',
    depart:'10:00',
    arrive:'12:00'
  },
  {
    flight_no: 'AI-699',
    price: 4009,
    source: 'Mumbai',
    destination:'New Delhi',
    depart:'05:00',
    arrive:'07:00'
  },
  {
    flight_no: 'AI-900',
    price: 4799,
    source: 'Mumbai',
    destination:'New Delhi',
    depart:'10:00',
    arrive:'12:00'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/